package Report_Chapter07;

import java.util.ArrayList;
import java.util.Scanner;

public class ArrayListProgram {
    public static void main(String[] args) {
        ArrayList<Integer> list = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("1.ADD 2.REMOVE 3.PRINT POSITION 4.PRINT ALL 5.EXIT");
            System.out.print("실행동작: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("입력값: ");
                    int numA = scanner.nextInt();
                    if (!list.contains(numA)) {
                        list.add(numA);
                    } 
                    break;
                case 2:
                    System.out.print("삭제 값: ");
                    int numD = scanner.nextInt();
                    for(int i=0;i<list.size();i++) {
                        if(list.get(i).equals(numD)) {
                            list.remove(i);
                        }
                    }
                    break;
                case 3:
                    System.out.print("검색 값: ");
                    int numF = scanner.nextInt();
                    for(int i=0;i<list.size();i++) {
                    	if(list.get(i).equals(numF)) {
                    		System.out.print(numF+" 값은 "+(i+1)+"번째에 위치");
                    	}
                    }
                    System.out.println();
                    break;
                case 4:
                    System.out.print("모든 값: ");
                    for(int i=0;i<list.size();i++) {
                    	int value=list.get(i);
                    	System.out.print(value+" ");
                    }
                    System.out.println();
                    break;
                case 5:
                    System.out.println("프로그램을 종료합니다.");
                    scanner.close();
                    System.exit(0);
                
            }
            System.out.println();
        }
    }
}

