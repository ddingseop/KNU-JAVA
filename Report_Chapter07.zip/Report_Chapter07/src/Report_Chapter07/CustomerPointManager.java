package Report_Chapter07;

import java.util.HashMap;
import java.util.Scanner;

public class CustomerPointManager {
    public static void main(String[] args) {
        HashMap<String, Integer> customerPoints = new HashMap<>();
        Scanner scanner = new Scanner(System.in);

        System.out.println("** 포인트 관리 프로그램입니다 **");

        while (true) {
            System.out.print("이름과 포인트 입력>> ");
            String input = scanner.nextLine();

            if (input.equals("exit")) {
                System.out.println("프로그램을 종료합니다...");
                break;
            }

            String[] tokens = input.split(" ");
            String name = tokens[0];
            int points= Integer.parseInt(tokens[1]);

            if (customerPoints.containsKey(name)) {
                int currentPoints = customerPoints.get(name);
                customerPoints.put(name, currentPoints + points);
            } else {
                customerPoints.put(name, points);
            }

            for (String customer : customerPoints.keySet()) {
                System.out.print("(" + customer + "," + customerPoints.get(customer) + ")");
            }
            System.out.println();
        }

        scanner.close();
    }
}


