package ch10;

import javax.swing.*;
import java.awt.*;
import java.util.Random;

class CirclePanel extends JPanel {
    private int x = 0;
    private int y = 0;
    private Random rand = new Random();

    public CirclePanel() {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    moveCircle();
                    repaint();
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        thread.start();
    }

    private synchronized void moveCircle() {
        int panelWidth = getWidth();
        int panelHeight = getHeight();

        // 패널 크기가 50보다 작으면 위치를 변경하지 않음
        if (panelWidth < 50 || panelHeight < 50) {
            return;
        }

        x = rand.nextInt(panelWidth - 50);
        y = rand.nextInt(panelHeight - 50);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.MAGENTA);
        g.drawOval(x, y, 50, 50);
    }
}

public class MovingCircleFrame extends JFrame {
    public MovingCircleFrame() {
        setTitle("원 이동");
        setSize(300, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        add(new CirclePanel());
        setVisible(true);
    }

    public static void main(String[] args) {
        new MovingCircleFrame();
    }
}
