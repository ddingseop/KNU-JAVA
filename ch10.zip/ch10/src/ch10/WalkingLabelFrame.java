package ch10;

import javax.swing.*;

class WalkingLabel extends JLabel implements Runnable {
    private String text = "나는 당신을 사랑합니다.";
    private int index = 0;
    private Thread thread;

    public WalkingLabel() {
        thread = new Thread(this);
        thread.start();
    }

    @Override
    public void run() {
        try {
            while (true) {
                index++;
                if (index > text.length()) {
                    index = 0;
                }
                setText(text.substring(0, index));
                Thread.sleep(500); 
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

public class WalkingLabelFrame extends JFrame {
    public WalkingLabelFrame() {
        setTitle("Walking Label");
        setSize(300, 100);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        add(new WalkingLabel());
        setVisible(true);
    }

    public static void main(String[] args) {
        new WalkingLabelFrame();
    }
}

