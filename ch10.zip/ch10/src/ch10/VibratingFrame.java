package ch10;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Random;

public class VibratingFrame extends JFrame implements Runnable {
	private Thread th; //진동하는 스레드
	public VibratingFrame() {
		setTitle("진동하는 프레임 만들기");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(200,200);
		setLocation(300,300); 
		setVisible(true);
		
		getContentPane().addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) { //마우스 눌렸을때 발생하는 이벤트
				if(!th.isAlive()) { //스레드가 실행중이지 않으면
					return; //마우스가 눌렸을때 스레드가 실행중이지 않으면 아무런 작업 안함
				}
				th.interrupt(); //스레드가 실행중이면 스레드 중단시킴
			}
		});
		
		th = new Thread(this); //진동하는 스레드 객체 생성
		th.start(); //진동 시작
	}

	@Override
	public void run() { //프레임의 진동을 일으키기 위해 20ms마다 프레임위치 랜덤 이동
		Random r = new Random();
		while(true) {
			try {
				Thread.sleep(20); 
			}
			catch(InterruptedException e){
				return; //리턴하면 스레드 종료
			}
			int x = getX() + r.nextInt()%5; //새 위치 x
			int y = getY() + r.nextInt()%5; //새 위치 y
			setLocation(x, y); //프레임 위치 이동
		}
	}

	public static void main(String [] args) {
		new VibratingFrame();
	}
} 
