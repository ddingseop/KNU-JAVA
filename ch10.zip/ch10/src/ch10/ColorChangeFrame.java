package ch10;
import javax.swing.*;
import java.awt.*;

class ColorThread extends Thread {
    private JFrame frame;

    public ColorThread(JFrame frame) {
        this.frame = frame;
    }

    @Override
    public void run() {
        try {
            frame.getContentPane().setBackground(Color.YELLOW);
            frame.setTitle("실행 시작");
            Thread.sleep(10000); // 10초 대기
            frame.getContentPane().setBackground(Color.BLUE);
            frame.setTitle("실행 종료");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

public class ColorChangeFrame extends JFrame {
    public ColorChangeFrame() {
        setTitle("실행 시작");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);

        ColorThread thread = new ColorThread(this);
        thread.start();
    }

    public static void main(String[] args) {
        new ColorChangeFrame();
    }
}
