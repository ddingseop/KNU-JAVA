package ch10;

public class Exercise1 {
	public static void main(String[] agrs) {
		ExThread th = new ExThread();
		th.start();
		for(int i=1; i<1000; i++) {
			System.out.print(i);
			if(i%10 == 0) System.out.println();
			else System.out.print("\t");
		}
	}
}
class ExThread extends Thread {
	@Override
	public void run() {
		for(int i=0; i<100; i++) {
			for(char ch='A'; ch<='z'; ch++) {
				System.out.print(ch);
			}
			System.out.println();
		}
	}
}

