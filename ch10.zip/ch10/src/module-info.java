/**
 * 
 */
/**
 * 
 */
module ch10 {
	requires java.desktop;
}