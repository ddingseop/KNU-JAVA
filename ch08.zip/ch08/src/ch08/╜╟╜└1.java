package ch08;
import javax.swing.*;
import java.awt.*;

public class 실습1 extends JFrame {

	public 실습1() {
		setTitle("Border Layout Example");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container c = getContentPane();
		c.setLayout(new BorderLayout(5, 5));
		c.add(new JButton("Menu"), BorderLayout.NORTH);
		c.add(new JButton("Console"), BorderLayout.SOUTH);
		//c.add(new JButton("mul"), BorderLayout.EAST);
		c.add(new JButton("Dir"), BorderLayout.WEST);
		c.add(new JButton("Editor"), BorderLayout.CENTER);
		setSize(300, 300);
		setVisible(true);
	}
	public static void main(String[] args) {
		new 실습1();

	}

}
