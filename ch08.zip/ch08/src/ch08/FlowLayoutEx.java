package ch08;
import javax.swing.*;
import java.awt.*;
public class FlowLayoutEx extends JFrame {
	public FlowLayoutEx() {
		setTitle("Flow Layout Example");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container c = getContentPane();
		//왼쪽 정렬로 수평간격을 30 수직 간격을 40픽셀로 배치하기
		c.setLayout(new FlowLayout(FlowLayout.LEFT, 30, 40));
		c.add(new JButton("add"));
		c.add(new JButton("sub"));
		c.add(new JButton("mul"));
		c.add(new JButton("div"));
		c.add(new JButton("Calculator"));
		setSize(300, 300);
		setVisible(true);
	}
	public static void main(String[] args) {
		new FlowLayoutEx();
	}

}
