package ch08;
import javax.swing.*;
import java.awt.*;

public class 실습2 extends JFrame{
	
	public 실습2() {
		setTitle("Exercise2");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		
		JPanel jp = new JPanel();
		//1행 2열의 격자를 가지며, 컴포넌트 사이의 수평, 수직 간격은 각각 5픽셀
		jp.setLayout(new GridLayout(1, 2, 5, 5));
		jp.add(new JButton("Test"));
		
		JPanel jp1 = new JPanel();
		//2행 1열의 격자를 가지며, 컴포넌트 사이의 수평, 수직 간격은 각각 5픽셀
		jp1.setLayout(new GridLayout(2, 1, 5, 5));
		jp1.add(new JButton("Test1"));
		jp1.add(new JButton("Test2"));
		jp.add(jp1);
		
		c.add(jp, BorderLayout.SOUTH);
						
		setSize(300, 200);
		setVisible(true);
	}

	public static void main(String[] args) {
		new 실습2();
	}

}
