/**
 * 
 */
/**
 * 
 */
module ch08 {
	requires java.desktop;
}