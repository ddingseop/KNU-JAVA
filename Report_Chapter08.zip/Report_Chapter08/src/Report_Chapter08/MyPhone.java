package Report_Chapter08;
import javax.swing.*;
import java.awt.*;

public class MyPhone extends JFrame{
	 private JPanel lcdJPanel;
	 private JTextArea lcdJTextArea;
	 private String lcdOutput = "";
	 private JPanel keyJPanel;
	 private JButton keyJButton[];
	 
	 public MyPhone() {
	        setTitle("MyPhone");
	        setSize(300, 500);
	        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	        lcdJPanel = new JPanel();
	        lcdJTextArea = new JTextArea(lcdOutput, 5, 10);
	        lcdJPanel.setLayout(new GridLayout(1, 1));
	        lcdJPanel.add(lcdJTextArea);

	        keyJPanel = new JPanel();
	        keyJPanel.setLayout(new GridLayout(5, 3));
	        keyJButton = new JButton[15];
	        String[] buttonLabels = {
	        		"Send", "clr", "End",
	                "1", "2", "3",
	                "4", "5", "6",
	                "7", "8", "9",
	                "*", "0", "#"
	        };

	        for (int i = 0; i < 15; i++) {
	            keyJButton[i] = new JButton(buttonLabels[i]);
	            keyJPanel.add(keyJButton[i]);
	        }

	        getContentPane().add(BorderLayout.NORTH, lcdJPanel);
	        getContentPane().add(BorderLayout.CENTER, keyJPanel);

	        setVisible(true);
	    }
	public static void main(String[] args) {
		new MyPhone();

	}

}
