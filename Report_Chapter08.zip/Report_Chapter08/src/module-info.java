/**
 * 
 */
/**
 * 
 */
module Report_Chapter08 {
	requires java.desktop;
}