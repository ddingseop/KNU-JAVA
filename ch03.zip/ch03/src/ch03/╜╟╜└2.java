package ch03;

import java.util.InputMismatchException;
import java.util.Scanner;

public class 실습2 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		char day[]= {'일','월','화','수','목','금','토'};
		while(true) {
			System.out.print("정수를 입력하세요>>");
			int n;
			try {
				n=sc.nextInt();
			}
			catch(InputMismatchException e){
				System.out.println("정수를 입력하지 않았습니다.");
				sc.next();
				continue;
			}
			if(n<0) {
				System.out.println("프로그램을 종료합니다.");
				break;
			}
			switch(n%day.length) {
			case 0:
				System.out.println("일");
				break;
			case 1:
				System.out.println("월");
				break;
			case 2:
				System.out.println("화");
				break;
			case 3:
				System.out.println("수");
				break;
			case 4:
				System.out.println("목");
				break;
			case 5:
				System.out.println("금");
				break;
			case 6:
				System.out.println("토");
				break;
			}
		}
	}
}
