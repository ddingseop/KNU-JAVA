package ch03;

import java.util.Scanner;

public class 실습1 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int a[]=new int[11];
		System.out.print("값을 입력하세요");
		int n=sc.nextInt();
		for(int i=0;i<a.length;i++) {
			a[i]=i*10;
			if(n==a[i]) {
				System.out.println(n+"은 "+(i+1)+"번째 값입니다.");
			}
		}
		sc.close();
	}
}