package ch03;

import java.util.Scanner;

public class ForSample {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int count=0,n=0;
		double sum=0;
		
		System.out.println("정수입력하고 마직막에 0 입력");
		while((n=sc.nextInt())!=0) {
			sum+=n;
			count++;
		}
		System.out.println("수의 갯는"+count+"개");
		System.out.println("평균은"+sum/count+"입니다");
		sc.close();
	}
}
