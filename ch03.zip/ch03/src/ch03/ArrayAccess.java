package ch03;

import java.util.Scanner;

public class ArrayAccess {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int intArray[]=new int[5];
		int max=0;
		System.out.println("양수 5개 입력");
		for(int i=0;i<5;i++) {
			intArray[i]=sc.nextInt();
			if(intArray[i]>max) {
				max=intArray[i];
			}
		}
		System.out.println("가장 큰수는 "+max);
		sc.close();
	}
}
