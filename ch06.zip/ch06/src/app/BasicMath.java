package app;

public class BasicMath {
	public static double sum(double a,double b) {
		return a+b;
	}
	public static double sub(double a,double b) {
		return a-b;
	}
	public double mul(double a,double b) {
		return a*b;
	}
}
