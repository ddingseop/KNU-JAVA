package app;

public class Basic2Math {
	private double a;
	private double b;
	public Basic2Math(double a,double b) {
		this.a=a;
		this.b=b;
	}
	public void setA(double a) {
		this.a=a;
	}
	public void setB(double b) {
		this.b=b;
	}
	public double sum() {
		return BasicMath.sum(a,b);
	}
	public double sub() {
		return BasicMath.sub(a,b);
	}
	public double mul() {
		BasicMath m=new BasicMath();
		return m.mul(a,b);
	}
	@Override
	public boolean equals(Object obj) {
		Basic2Math bb=(Basic2Math)obj;
		if(a==bb.a&&b==bb.b) {
			return true;
		}
		else {
			return false;
		}
	}
}
