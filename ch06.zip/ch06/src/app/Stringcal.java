package app;

import java.util.Scanner;
import java.util.StringTokenizer;

public class Stringcal {

	public static void main(String[] args) {
		int sum=0;
		double avg=0.0;
		Scanner sc=new Scanner(System.in);
		String a=sc.nextLine();
		StringTokenizer b=new StringTokenizer(a,"+");
		int n=b.countTokens();
		while(b.hasMoreTokens()) {
			String token=b.nextToken();
			token=token.trim();
			int result=Integer.parseInt(token);
			sum+=result;
		}
		avg=sum/n;
		System.out.print("합="+sum);
		System.out.println(", 평균="+avg);
	}

}
