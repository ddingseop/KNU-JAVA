package app;

public class MainMath {

	public static void main(String[] args) {
		Basic2Math m1=new Basic2Math(3.0,2.0);
		System.out.println("Sum a+b = "+m1.sum());
		System.out.println("Sub a-b = "+m1.sub());
		System.out.println("Mul a*b = "+m1.mul());
		Basic2Math m2=new Basic2Math(3.0,2.0);
		if(m2.equals(m1)) {
			System.out.println("두 인스턴스는 값이 같다.");
		}
	}

}
