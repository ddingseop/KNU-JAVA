package app;

public class ObjectPropertyEx {

	public static void main(String[] args) {
		Point p=new Point(2,3);
		System.out.println(p.getClass().getName());  //클래스이름
		System.out.println(p.hashCode());  //해시 코드 값
		System.out.println(p.toString());  //객체의 문자열
		System.out.println(p); //p는 p.toString()으로 자동 변환됨
	}

}
