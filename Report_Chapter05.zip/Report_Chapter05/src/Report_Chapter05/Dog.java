package Report_Chapter05;

public class Dog extends Animal{
	public Dog(String name) {
		super(name);
	}
	public String bark() {
		return "멍멍";
	}
}
