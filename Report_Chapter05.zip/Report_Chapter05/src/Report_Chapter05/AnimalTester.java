package Report_Chapter05;

public class AnimalTester {

	public static void main(String[] args) {
		Dog d=new Dog("강아지");
		System.out.println("동물 : "+d.getName());
		System.out.println("울음소리 : "+d.bark());

	}

}
