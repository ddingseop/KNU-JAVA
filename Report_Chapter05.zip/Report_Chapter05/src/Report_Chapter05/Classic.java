package Report_Chapter05;

public class Classic extends Music{
	private String composer;
	
	public Classic(String name,int year, String composer) {
		super(name,year);
		this.composer=composer;
	}
	public String toString() {
        return "Classic [곡명=" + name + ", 연도=" + year + ", 작곡가=" + composer + "]";
    }
}
