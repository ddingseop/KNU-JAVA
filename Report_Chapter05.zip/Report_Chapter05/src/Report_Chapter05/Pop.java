package Report_Chapter05;

public class Pop extends Music{
	private String singer;
	public Pop(String name, int year, String singer) {
        super(name, year);
        this.singer = singer;
    }
	public String toString() {
        return "Pop [곡명=" + name + ", 연도=" + year + ", 가수=" + singer + "]";
    }
}
