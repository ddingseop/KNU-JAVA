package ch05;

abstract class Music implements Payable{
	String name;
	int year;
	Music(String name,int year){  //생성자
		this.name=name;
		this.year=year;
	}
	public String getName() {
		return name;
	}
	public int getYear() {
		return year;
	}
	public void print() {
		System.out.println("곡명="+name+", 연도="+year);
	}
	
}

class Classic extends Music{
	String composer;
	public Classic(String name,int year,String composer) { //생성자
		super(name,year); //뮤직에 있는 생성자 가져오기
		this.composer=composer;
	}
	public String getComposer() {
		return composer;
	}
	public void setComposer(String composer) {
		this.composer=composer;
	}
	public String play() {
		return (getName()+"을 연주합니다.");
	}
	public void print() { 
		super.print();
		System.out.println("작곡가="+composer);
	}
}

class Pop extends Music{
	String singer;
	public Pop(String name,int year,String singer) {
		super(name,year);
		this.singer=singer;
	}
	public String getSinger() {
		return singer;
	}
	public void setSinger(String singer) {
		this.singer=singer;
	}
	public String play() {
		return (getName()+"을 연주합니다.");
	}
	public void print() {
		super.print();
		System.out.println("가수="+singer);
	}
}

public class PayableInterfaceTest {

	
	public static void main(String[] args) {
		Classic a=new Classic("베토벤 교향굑",1804,"베토벤");
		Pop b=new Pop("Shape of you",2017,"Ed Sheeran");
		
		System.out.println("Classic 정보:");
		a.print();
		System.out.println(a.play());
		
		System.out.println("\nPop 정보:");
		b.print();
		System.out.println(b.play());

	}

}
