package ch05;

public interface Payable {
	String play();
}
