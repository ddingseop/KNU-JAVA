package Report_Chapter04;

public class Account1 {
	private String name;
	private double balance;
	
	public Account1(String n) {
		name=n;
		balance=0.0;
	}
	public String getName() {
		return name;
	}
	public double getBalance() {
		return balance;
	}
	public void credit(double b) {
		balance+=b;
	}
	public void print() {
		System.out.println("예금주 : "+name);
		System.out.printf("잔액 : %.2f\n",balance);
	}
	public void addInterest(double interestRates) {
		double interest=balance*interestRates;
		balance+=interest;
	}
}
