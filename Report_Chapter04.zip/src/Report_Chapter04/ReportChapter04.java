package Report_Chapter04;

import java.util.Scanner;

public class ReportChapter04 {
	
	static void method1() {
		Scanner sc=new Scanner(System.in);
		 System.out.print("Enter deposit amount for account1: ");
	        double deposit1 = sc.nextDouble();
	        Account1 account1 = new Account1("X");
	        account1.credit(deposit1);
	        System.out.println("Account1 balance: " + account1.getBalance());
	        
	        System.out.print("Enter deposit amount for account2: ");
	        double deposit2 = sc.nextDouble();
	        Account1 account2 = new Account1("Y");
	        account2.credit(deposit2);
	        System.out.println("Account2 balance: " + account2.getBalance());
		    System.out.println();
	}
	static void method2() {
		Account1 account = new Account1("홍길동");
		account.credit(1000.0);
		account.print();
		account.addInterest(0.011);
		account.print();
		System.out.println();
	}
	static void method3() {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter first interger: ");
		int num1 = sc.nextInt();
		System.out.print("Enter second interger: ");
		int num2 = sc.nextInt();
		System.out.println();
		System.out.println("Sum is " + (num1 + num2));
        System.out.println("Product is : " + (num1 * num2));
        System.out.println("Difference is : " + (num1 - num2));
        if (num2 != 0) {
            System.out.println("Quotient is : " + (num1 / num2));
        } 
        else {
            System.out.println("0으로 나눌 수 없습니다.");
        }
        sc.close();
	}

	public static void main(String[] args) {
		method1();
		method2();
		method3();
	}

}
