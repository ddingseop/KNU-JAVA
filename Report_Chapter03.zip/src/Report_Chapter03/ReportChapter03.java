package Report_Chapter03;

import java.util.Scanner;

public class ReportChapter03 {

	static void method1() {
		Scanner sc=new Scanner(System.in);
		int sum=0;
		int count=0;
		while(true) {
			System.out.print("Enter grade: ");
			int score=sc.nextInt();
			if(score==-1) {
				break;
			}
			sum+=score;
			count++;
		}
		if(count>0) {
			int avg=(int)sum/count;
			System.out.println("Total of "+count+" student grades is "+sum);
			System.out.println("Class average is "+avg);
		}
		else {
			System.out.println("입력된 점수 X");
		}
		sc.close();
	}
	
    static void method2() {
    	Scanner sc=new Scanner(System.in);
    	int a=0,b=0,c=0,d=0,f=0;
    	while(true) {
    		System.out.print("Enter grade: ");
    		int score=sc.nextInt();
    		if(score==-1) {
    			break;
    		}
    		char grade;
    		switch(score/10) {
    		case 9:
    			grade='A';
    			a++;
    			break;
    		case 8:
    			grade='B';
    			b++;
    			break;
    		case 7:
    			grade='C';
    			c++;
    			break;
    		case 6:
    			grade='D';
    			d++;
    			break;
    		case 5:case 4:case 3:case 2:case 1:case 0:
    			grade='F';
    			f++;
    			break;
    		}
    	}
    	System.out.println("Number of students who received each grade:");
		System.out.println("A: " + a);
        System.out.println("B: " + b);
        System.out.println("C: " + c);
        System.out.println("D: " + d);
        System.out.println("F: " + f);
        
        sc.close();
	}
    
    static void method3() {
		Scanner sc=new Scanner(System.in);
		System.out.print("금액을 입력하시오 : ");
		int money=sc.nextInt();
		int ft=money/50000;
		int change=money%50000;
		int tt=change/10000;
		change%=10000;
		int th=change/1000;
		change%=1000;
		int fh=change/500;
		change%=500;
		int h=change/100;
		change%=100;
		int f=change/50;
		change%=50;
		int t=change/10;
		change%=10;
		int o=change;
		if(ft>0) {
			System.out.println("오만원권 "+ft+"매");
		}
		if(tt>0) {
			System.out.println("만원권 "+tt+"매");
		}
		if(th>0) {
			System.out.println("천원권 "+th+"매");
		}
		if(fh>0) {
			System.out.println("오백원 "+fh+"개");
		}
		if(h>0) {
			System.out.println("백원 "+h+"개");
		}
		if(f>0) {
			System.out.println("오십원 "+f+"개");
		}
		if(t>0) {
			System.out.println("십원 "+t+"개");
		}
		if(o>0) {
			System.out.println("일원 "+o+"개");
		}
		sc.close();
	}
    
	public static void main(String[] args) {
		method1();
		method2();
		method3();
	}
}
