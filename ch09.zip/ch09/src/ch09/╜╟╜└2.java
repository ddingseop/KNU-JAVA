package ch09;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class 실습2 extends JFrame{
	public 실습2() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container c=getContentPane();
		c.setLayout(new GridLayout(4,3));
		for(int i=0;i<12;i++) {
			String text=Integer.toString(i);
			JLabel la=new JLabel(text);
			la.setBackground(Color.WHITE);
			la.setOpaque(true);
			la.addMouseListener(new MouseAdapter() {
				public void mousePressed(MouseEvent e) {
					int r=(int)(Math.random()*255);
					int g=(int)(Math.random()*255);
					int b=(int)(Math.random()*255);
					JLabel la2=(JLabel)e.getSource();
					la2.setBackground(new Color(r,g,b));
				};
			});
			c.add(la);
		}
		setSize(300,300);
		setVisible(true);
	}
	public static void main(String[] args) {
		new 실습2();

	}
}
