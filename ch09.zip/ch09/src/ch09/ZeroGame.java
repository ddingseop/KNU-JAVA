package ch09;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class ZeroGame extends JFrame implements ActionListener {
    private int currentNumber;
    private JButton addButton, subtractButton, divideButton;
    private JLabel numberLabel;
    private Random random;

    public ZeroGame() {
        setTitle("0으로 만들기 게임");
        setLayout(new FlowLayout());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 200);

        random = new Random();
        currentNumber = random.nextInt(60) + 1;

        numberLabel = new JLabel(String.valueOf(currentNumber));
        numberLabel.setFont(new Font("Serif", Font.BOLD, 48));
        add(numberLabel);

        addButton = new JButton("+2");
        subtractButton = new JButton("-1");
        divideButton = new JButton("%4");

        addButton.addActionListener(this);
        subtractButton.addActionListener(this);
        divideButton.addActionListener(this);

        add(addButton);
        add(subtractButton);
        add(divideButton);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton source = (JButton) e.getSource();

        if (source == addButton) {
            currentNumber += 2;
        } else if (source == subtractButton) {
            currentNumber -= 1;
        } else if (source == divideButton) {
            currentNumber %= 4;
        }

        numberLabel.setText(String.valueOf(currentNumber));
        source.setEnabled(false);

        if (currentNumber == 0) {
            resetGame();
        }
    }

    private void resetGame() {
        currentNumber = random.nextInt(60) + 1;
        numberLabel.setText(String.valueOf(currentNumber));
        addButton.setEnabled(true);
        subtractButton.setEnabled(true);
        divideButton.setEnabled(true);
    }

    public static void main(String[] args) {
        new ZeroGame();
    }
}

