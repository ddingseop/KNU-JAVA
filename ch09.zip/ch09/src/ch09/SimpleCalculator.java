package ch09;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SimpleCalculator extends JFrame implements ActionListener {
    private JTextField inputField, resultField;
    private String operator;
    private double firstNumber;

    public SimpleCalculator() {
        setTitle("간단한 계산기");
        setLayout(new BorderLayout());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 500);

        // Display panel with GridBagLayout
        JPanel displayPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // "수식" label
        JLabel inputLabel = new JLabel("수식:");
        inputLabel.setFont(new Font("Arial", Font.BOLD, 24));
        gbc.gridx = 0;
        gbc.gridy = 0;
        displayPanel.add(inputLabel, gbc);

        // Input field
        inputField = new JTextField();
        inputField.setFont(new Font("Arial", Font.BOLD, 24));
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.weightx = 1.0;
        displayPanel.add(inputField, gbc);

        // "결과" label
        JLabel resultLabel = new JLabel("결과:");
        resultLabel.setFont(new Font("Arial", Font.BOLD, 24));
        gbc.gridx = 2;
        gbc.gridy = 0;
        gbc.weightx = 0;
        displayPanel.add(resultLabel, gbc);

        // Result field
        resultField = new JTextField();
        resultField.setFont(new Font("Arial", Font.BOLD, 24));
        resultField.setEditable(false);
        gbc.gridx = 3;
        gbc.gridy = 0;
        gbc.weightx = 1.0;
        displayPanel.add(resultField, gbc);

        add(displayPanel, BorderLayout.NORTH);

        // Button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(4, 4));

        String[] buttons = {
            "0", "1", "2", "3",
            "4", "5", "6", "7",
            "8", "9", "CE", "계산",
            "+", "-", "*", "/"
        };

        for (String text : buttons) {
            JButton button = new JButton(text);
            button.setFont(new Font("Arial", Font.BOLD, 24));
            button.addActionListener(this);
            buttonPanel.add(button);
        }

        add(buttonPanel, BorderLayout.CENTER);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();

        if (command.charAt(0) >= '0' && command.charAt(0) <= '9') {
            inputField.setText(inputField.getText() + command);
        } else if (command.equals("CE")) {
            inputField.setText("");
            resultField.setText("");
            operator = null;
        } else if (command.equals("계산")) {
            if (operator != null && !inputField.getText().isEmpty()) {
                try {
                    String[] parts = inputField.getText().split("\\" + operator);
                    if (parts.length == 2) {
                        double secondNumber = Double.parseDouble(parts[1]);
                        double result = 0;
                        switch (operator) {
                            case "+":
                                result = firstNumber + secondNumber;
                                break;
                            case "-":
                                result = firstNumber - secondNumber;
                                break;
                            case "*":
                                result = firstNumber * secondNumber;
                                break;
                            case "/":
                                result = firstNumber / secondNumber;
                                break;
                        }
                        resultField.setText(String.valueOf(result));
                    } else {
                        resultField.setText("Error");
                    }
                } catch (NumberFormatException ex) {
                    resultField.setText("Error");
                }
            } else {
                resultField.setText("Error");
            }
        } else {
            if (!inputField.getText().isEmpty()) {
                try {
                    firstNumber = Double.parseDouble(inputField.getText());
                    operator = command;
                    inputField.setText(inputField.getText() + command);
                } catch (NumberFormatException ex) {
                    resultField.setText("Error");
                }
            } else {
                resultField.setText("Error");
            }
        }
    }

    public static void main(String[] args) {
        new SimpleCalculator();
    }
}
