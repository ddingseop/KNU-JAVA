package ch11;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class GUIServer {
    private static JLabel label;
    private static int x = 100, y = 100;

    public static void main(String[] args) {
        JFrame frame = new JFrame("Server");
        frame.setSize(400, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        label = new JLabel("Java");
        label.setFont(new Font("Serif", Font.PLAIN, 24));
        label.setBounds(x, y, 100, 50);

        JPanel panel = new JPanel(null);
        panel.add(label);
        frame.add(panel);

        frame.setVisible(true);

        try (ServerSocket serverSocket = new ServerSocket(12345)) {
            System.out.println("Server started. Waiting for connection...");
            Socket socket = serverSocket.accept();
            System.out.println("Client connected.");

            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            String inputLine;

            while ((inputLine = in.readLine()) != null) {
                moveLabel(inputLine);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void moveLabel(String direction) {
        switch (direction) {
            case "UP":
                y = Math.max(y - 10, 0);
                break;
            case "DOWN":
                y = Math.min(y + 10, 350);
                break;
            case "LEFT":
                x = Math.max(x - 10, 0);
                break;
            case "RIGHT":
                x = Math.min(x + 10, 350);
                break;
        }
        label.setLocation(x, y);
    }
}

