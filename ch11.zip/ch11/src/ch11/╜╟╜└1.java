package ch11;

import java.io.*;
import java.util.Scanner;;

public class 실습1 {
   public static void main(String[] args) {
      FileReader in=null;
      try {
    	  String src="c:\\windows\\system.ini";
    	  Scanner sc=new Scanner(new FileReader(src));
    	  int n=0;
    	  while(sc.hasNext()) {
    		  String line=sc.nextLine();
    		  n++;
    		  System.out.println(n+": "+line);
    	  }
    	  sc.close();
      }
      catch(IOException e) {
    	  System.out.println("입출력 오류");
      }
   }
}
