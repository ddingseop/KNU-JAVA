package ch11;

import javax.swing.*;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.Socket;

public class GUIClient {
    private static PrintWriter out;

    public static void main(String[] args) {
        JFrame frame = new JFrame("Client");
        frame.setSize(400, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BorderLayout(0, 0));
        JButton connectButton=new JButton("Connect");
        JButton upButton=new JButton("UP");
        JButton downButton=new JButton("DOWN");
        JButton leftButton=new JButton("LEFT");
        JButton rightButton=new JButton("RIGHT");
        buttonPanel.add(upButton, BorderLayout.NORTH);
        buttonPanel.add(downButton, BorderLayout.SOUTH);
        buttonPanel.add(rightButton, BorderLayout.EAST);
        buttonPanel.add(leftButton, BorderLayout.WEST);
        buttonPanel.add(connectButton, BorderLayout.CENTER);

        panel.add(buttonPanel);
        frame.add(panel);
        frame.setVisible(true);

        connectButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Socket socket = new Socket("localhost", 12345);
                    out = new PrintWriter(socket.getOutputStream(), true);
                    connectButton.setEnabled(false);
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });

        ActionListener buttonListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JButton source = (JButton) e.getSource();
                if (out != null) {
                    out.println(source.getText());
                }
            }
        };

        upButton.addActionListener(buttonListener);
        downButton.addActionListener(buttonListener);
        leftButton.addActionListener(buttonListener);
        rightButton.addActionListener(buttonListener);
    }
}

