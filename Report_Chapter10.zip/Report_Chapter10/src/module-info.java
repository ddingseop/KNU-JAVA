/**
 * 
 */
/**
 * 
 */
module Report_Chapter10 {
	requires java.desktop;
}