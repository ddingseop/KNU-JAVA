package Report_Chapter10;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Random;

public class Report12 extends JFrame {
    Report12() {
        super("쓰레드를 가진 겜블링");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(new GamePanel()); // GamePanel을 컨텐트팬으로 등록
        setSize(300, 200);
        setVisible(true);
    }

    class GamePanel extends JPanel { // 화면 디자인
        JLabel[] label = new JLabel[3]; // 3개의 레이블
        JLabel result = new JLabel("마우스를 클릭할 때마다 게임합니다."); // 결과 출력
        GamblingThread thread;

        public GamePanel() {
            setLayout(null); // 절대 위치에 컴포넌트 배치
            for (int i = 0; i < label.length; i++) {
                label[i] = new JLabel("0"); // 초기 레이블 생성
                label[i].setSize(60, 30); // 레이블 크기
                label[i].setLocation(30 + 80 * i, 50); // 레이블 위치
                label[i].setHorizontalAlignment(JLabel.CENTER);
                label[i].setOpaque(true); // 레이블에 배경색 설정이 가능하도록 설정
                label[i].setBackground(Color.MAGENTA);
                label[i].setForeground(Color.YELLOW);
                label[i].setFont(new Font("Tahoma", Font.ITALIC, 30));
                add(label[i]);
            }
            result.setHorizontalAlignment(JLabel.CENTER); // 결과를 출력할 레이블 생성
            result.setSize(250, 20);
            result.setLocation(30, 120);
            add(result);

            // TO DO 스레드(thread) 생성
            thread = new GamblingThread(label, result);
            thread.start(); // 스레드 시작

            addMouseListener(new MouseAdapter() { // 마우스 리스너 구현
                public void mousePressed(MouseEvent e) {
                    if (thread.isReady()) thread.startGambling();
                }
            });
        }
    }

    class GamblingThread extends Thread {
        JLabel[] label; // 게임 숫자를 출력
        JLabel result; // 결과를 출력
        long delay = 200; // 지연시간(sleep) 값
        boolean gambling = false; // 게임을 할 것인지 결정

        public GamblingThread(JLabel[] label, JLabel result) {
            this.label = label;
            this.result = result;
        }

        boolean isReady() {
            return !gambling; // 게임 중이면 준비되지 않았음
        }

        synchronized public void waitForGambling() { // 게임하지 않으면 기다림
            try {
                while (!gambling) {
                    wait();
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        synchronized public void startGambling() { // 마우스 클릭으로 게임을 진행
            gambling = true;
            notify();
        }

        public void run() { // 게임을 진행
            Random random = new Random();

            while (true) {
                waitForGambling(); // 마우스 클릭에 의해 게임 진행 지시를 기다림

                // 0~4까지의 랜덤 수를 label에 넣음
                int first = random.nextInt(5);
                int second = random.nextInt(5);
                int third = random.nextInt(5);

                label[0].setText(Integer.toString(first));
                label[1].setText(Integer.toString(second));
                label[2].setText(Integer.toString(third));

                // 게임이 성공했는지 판별
                if (first == second && second == third) {
                    result.setText("축하합니다!!");
                } else {
                    result.setText("아쉽군요");
                }

                // 다음 게임이 가능하도록 설정
                gambling = false;

                try {
                    Thread.sleep(delay);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static void main(String[] arg) {
        new Report12();
    }
}

