package ch02;

import java.util.Scanner;

public class 실습3 {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("주문하세요: ");
		String cof=scanner.next();
		int num=scanner.nextInt();
		switch(cof) {
		case "에스프레소":
			System.out.println(2000*num+"원입니다");
			break;
		case "아메리카노":
			System.out.println(2500*num+"원입니다");
			break;
		case "카푸치노":
			System.out.println(3000*num+"원입니다");
			break;
		case "카페라떼":
			System.out.println(3500*num+"원입니다");
			break;
		default:
			break;
		}
		scanner.close();
	}
}
