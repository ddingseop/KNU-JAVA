package ch02;

public class 실습 {

	public static void main(String[] args) {
		int j=100;
		int i=((j%2==0)?(10):(20));
		System.out.println(i);
	}
}
