package ch02;

public class Var {
	public static void main(String[] args) {
		var price=200;
		var name="kitae";
		var pi=3.14;
		System.out.println("price="+(price+1000));
		System.out.println("name="+name);
		System.out.println("pi="+pi*10);

	}

}
