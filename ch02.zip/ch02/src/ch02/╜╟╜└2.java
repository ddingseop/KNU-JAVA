package ch02;

import java.util.Scanner;

public class 실습2 {

	public static void main(String[] args) {
		int sum=0;
		Scanner scanner=new Scanner(System.in);
		System.out.println("주문하세요: ");
		String cof=scanner.next();
		int price = 0;
		if(cof.equals("에스프레소")) {
			price=2000;
		}
		else if(cof.equals("아메리카노")) {
			price=2500;
		}
		else if(cof.equals("카푸치노")) {
			price=3000;
		}
		else if(cof.equals("카페라떼")) {
			price=3500;
		}
		int num=scanner.nextInt();
		sum+=price*num;
		System.out.println(sum+"원입니다.");
		scanner.close();
	}
}
