package ch04;

import java.util.Scanner;

public class phoneMain {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("인원수>>");
		int num=sc.nextInt();
		Phone[] p=new Phone[num];
		for(int i=0;i<p.length;i++) {
			System.out.print("이름과 전화번호 입력 >> ");
			String name=sc.next();
			String tel=sc.next();
			p[i]=new Phone(name,tel);
		}
		System.out.println("저장되었습니다...");
		while(true) {
			int n=0;
			System.out.print("검색할 이름>> ");
			String nam=sc.next();
			if(nam.equals("exit")) {
				System.out.println("프로그램을 종료합니다....");
				break;
			}
			for(int i=0;i<p.length;i++) {
				if(nam.equals(p[i].getName())) {
					System.out.println(p[i].getName()+"의 번호는 "+p[i].getTel());
					n++;
					break;
				}
			}
			if(n==0) {
				System.out.println(nam+"가 없습니다.");
			}
		}
		sc.close();
	}

}
