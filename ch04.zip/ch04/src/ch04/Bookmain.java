package ch04;

public class Bookmain {

	public static void main(String[] args) {
		Book littlePrince=new Book("어린왕자","생택쥐페리");
		Book loveStory=new Book("춘향전");
		System.out.println(littlePrince.getTitle()+" "+littlePrince.getAuthor());
		System.out.println(loveStory.getTitle()+" "+loveStory.getAuthor());

	}

}
