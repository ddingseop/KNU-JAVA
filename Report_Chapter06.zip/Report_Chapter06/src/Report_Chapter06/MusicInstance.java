package Report_Chapter06;

public class MusicInstance {

	public static void main(String[] args) {
		Music m = new Music("흥부전", 1700);
		Classic c = new Classic("캐논", 1732, "파핼벨");
		Pop p = new Pop("바람이 분다", 2004, "이소라");
		
		Music musics[]=new Music[3];
		musics[0] = m; musics[1] = c; musics[2] = p;
		
		for(Music currentMusic:musics) {
			if (currentMusic instanceof Classic) {
                Classic classicMusic = (Classic) currentMusic;
                System.out.println(classicMusic);
            } else if (currentMusic instanceof Pop) {
                Pop popMusic = (Pop) currentMusic;
                System.out.println(popMusic);
            } else {
                System.out.println(currentMusic);
            }
		}
		for(Music currentMusic:musics) {
			System.out.println(currentMusic.getClass().getSimpleName());
		}
	}

}
