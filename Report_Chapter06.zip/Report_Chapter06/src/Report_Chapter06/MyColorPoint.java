package Report_Chapter06;

abstract class MyPoint{
	private int x;
	private int y;
	public MyPoint(int x,int y) {
		this.setX(x);
		this.setY(y);
	}
	protected abstract void move(int x,int y);
	protected abstract void reverse();
	protected void show() {
		System.out.println(getX()+", "+getY());
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
}

public class MyColorPoint extends MyPoint{
	private String color;
	public MyColorPoint(int x,int y,String color) {
		super(x,y);
		this.color=color;
	}
	protected void move(int x,int y) {
		this.setX(x);
		this.setY(y);
	}
	protected void reverse() {
		int temp=this.getX();
		this.setX(this.getY());
		this.setY(temp);
	}
	public void show() {
        System.out.println(getX() + ", " + getY() + ", " + color);
    }
	public static void main(String[] args) {
		MyPoint p=new MyColorPoint(2,3,"blue");
		p.move(3, 4);
		p.reverse();
		p.show();

	}

}
