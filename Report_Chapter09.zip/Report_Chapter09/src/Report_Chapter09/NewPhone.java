package Report_Chapter09;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class NewPhone extends JFrame {
    private JPanel lcdJPanel;
    private JTextArea lcdJTextArea;
    private String lcdOutput = "";
    private JPanel keyJPanel;
    private JButton keyJButton[];

    public NewPhone() {
        setTitle("MyPhone");
        setSize(300, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        lcdJPanel = new JPanel();
        lcdJTextArea = new JTextArea(lcdOutput, 5, 10);
        lcdJTextArea.setEditable(false);
        lcdJPanel.setLayout(new GridLayout(1, 1));
        lcdJPanel.add(new JScrollPane(lcdJTextArea)); 

        keyJPanel = new JPanel();
        keyJPanel.setLayout(new GridLayout(5, 3));
        keyJButton = new JButton[15];
        String[] buttonLabels = {
                "Send", "clr", "End",
                "1", "2", "3",
                "4", "5", "6",
                "7", "8", "9",
                "*", "0", "#"
        };

        for (int i = 0; i < 15; i++) {
            keyJButton[i] = new JButton(buttonLabels[i]);
            keyJButton[i].addActionListener(new ButtonClickListener());
            keyJPanel.add(keyJButton[i]);
        }

        getContentPane().add(BorderLayout.NORTH, lcdJPanel);
        getContentPane().add(BorderLayout.CENTER, keyJPanel);

        setVisible(true);
    }

    private class ButtonClickListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String command = e.getActionCommand();

            switch (command) {
                case "Send":
                	lcdJTextArea.append("\n전화 거는중...\n");
                    break;
                case "clr":
                    if (lcdOutput.length() > 0) {
                        lcdOutput = lcdOutput.substring(0, lcdOutput.length() - 1);
                        lcdJTextArea.setText(lcdOutput);
                    }
                    break;
                case "End":
                    lcdOutput = "";
                    lcdJTextArea.setText(lcdOutput);
                    break;
                default: 
                    lcdOutput += command;
                    lcdJTextArea.setText(lcdOutput);
                    break;
            }
        }
    }

    public static void main(String[] args) {
        new NewPhone();
    }
}

