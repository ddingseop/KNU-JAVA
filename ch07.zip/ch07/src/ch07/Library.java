package ch07;

public class Library {
	String name;
	String publisher;
	String year;
	Library(String name,String publisher,String year){
		this.name=name;
		this.publisher=publisher;
		this.year=year;
	}
	public String getName() {
		return name;
	}
	public String getPublisher() {
		return publisher;
	}
	public String getYear() {
		return year;
	}
	public String toString() {
		return "name = "+name+" publisher = "+publisher+" year = "+year;
	}
}
