package ch07;

import java.util.*;

public class 실습1 {

	public static void main(String[] args) {
		ArrayList<String> a=new ArrayList<String>();
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<5;i++) {
			System.out.print("학점을 입력하세요>>");
			String s=sc.next();
			a.add(s);
		}
		for(int i=0;i<a.size();i++) {
			switch(a.get(i)){
			case "A":
				System.out.print("A:4.0 ");
				break;
			case "B":
				System.out.print("B:3.0 ");
				break;
			case "C":
				System.out.print("C:2.0 ");
				break;
			case "D":
				System.out.print("D:1.0 ");
				break;
			case "F":
				System.out.print("F:0.0 ");
				break;
			default:
				System.out.print("E:잘 못 입력하였습니다 ");
				break;
			}
				
		}
		
	}

}
