package ch07;

import java.util.*;

public class 실습2 {

	public static void main(String[] args) {
		ArrayList<Library> library=new ArrayList<Library>();
		Scanner sc=new Scanner(System.in);
		Library l;
		String book;
		String publisher;
		String year;
		int n=0;
		System.out.println("-------------도서관리시스템-------------");
		while(n!=5) {
			System.out.print("삽입:1, 삭제:2, 찾기:3, 전체보기:4, 종료:5 -->>");
			n=sc.nextInt();
			switch(n) {
			case 1:
				System.out.print("책이름 -->>");
				book=sc.next();
				System.out.print("출판사 -->>");
				publisher=sc.next();
				System.out.print("년도 -->>");
				year=sc.next();
				l=new Library(book,publisher,year);
				library.add(l);
				break;
			case 2:
				System.out.print("책이름 -->>");
				book=sc.next();
				for(int i=0;i<library.size();i++) {
					if(book.equals(library.get(i).getName())){
						library.remove(i);
					}
				}
				break;
			case 3:
				System.out.print("책이름 -->>");
				book=sc.next();
				for(int i=0;i<library.size();i++) {
					Library l2=library.get(i);
					if(book.equals(l2.getName())){
						System.out.println(book+"은 "+i+"번째 위치");
					}
				}
				break;
			case 4:
				for(int i=0;i<library.size();i++) {
					Library lb=library.get(i);
					System.out.println(lb);
				}
				break;
			case 5:
				System.out.print("프로그램을 종료합니다.");
				break;
			default:
				System.out.println("없는 번호입니다");
				continue;
			}
		}
	}

}