package Report_Chapter14;

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class TextClient {
    public static void main(String[] args) {
        Socket socket = null;
        PrintWriter out = null;
        BufferedReader stdIn = null;
        Scanner scanner = new Scanner(System.in);
        try {
            socket = new Socket("localhost", 12345);
            System.out.println("서버에 접속하였습니다...");

            out = new PrintWriter(socket.getOutputStream(), true);
            stdIn = new BufferedReader(new InputStreamReader(System.in));

            // 사용자로부터 입력을 받아 서버로 전송
            while (true) {
            	System.out.print("텍스트입력 >> ");
            	String userInput = scanner.nextLine();
                out.println(userInput);
                if ("끝".equals(userInput)) {
                    System.out.println("연결을 종료합니다.");
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (out != null) out.close();
                if (stdIn != null) stdIn.close();
                if (socket != null) socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
