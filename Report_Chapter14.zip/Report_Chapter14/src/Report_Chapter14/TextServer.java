package Report_Chapter14;

import java.io.*;
import java.net.*;

public class TextServer {
    public static void main(String[] args) {
        ServerSocket serverSocket = null;
        Socket clientSocket = null;
        BufferedReader in = null;

        try {
            serverSocket = new ServerSocket(12345);
            System.out.println("서버입니다. 클라이언트를 기다립니다...");
            clientSocket = serverSocket.accept();
            System.out.println("연결되었습니다.");

            // 클라이언트로부터 데이터를 읽기 위한 BufferedReader 생성
            in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

            String inputLine;
            // 클라이언트로부터 받은 메시지를 출력
            while ((inputLine = in.readLine()) != null) {
                if ("끝".equals(inputLine)) {
                    System.out.println("서버를 종료합니다.");
                    break;
                }
                System.out.println("... " + inputLine);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (in != null) in.close();
                if (clientSocket != null) clientSocket.close();
                if (serverSocket != null) serverSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

